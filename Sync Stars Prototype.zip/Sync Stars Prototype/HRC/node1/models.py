# models.py

from django.db import models

class HealthRecord(models.Model):
    node_id = models.CharField(max_length=100)
    patient_id = models.CharField(max_length=100)
    patient_name = models.CharField(max_length=255)
    diagnosis = models.TextField()
    treatment = models.TextField(blank=True)
    date_added = models.DateTimeField(auto_now_add=True)

    def __str__(self):
        return f"Health Record ({self.id}) - Patient: {self.patient_name}"

class Staff(models.Model):
    name = models.CharField(max_length=255)
    position = models.CharField(max_length=255)
    department = models.CharField(max_length=255)

    def __str__(self):
        return f"Staff: {self.name}, Position: {self.position}, Department: {self.department}"

class Appointment(models.Model):
    patient = models.ForeignKey(HealthRecord, on_delete=models.CASCADE)
    staff = models.ForeignKey(Staff, on_delete=models.CASCADE)
    date = models.DateField()
    time = models.TimeField()

    def __str__(self):
        return f"Appointment for {self.patient.patient_name} with {self.staff.name} on {self.date} at {self.time}"

class Medication(models.Model):
    name = models.CharField(max_length=255)
    dosage = models.CharField(max_length=50)
    frequency = models.CharField(max_length=50)
    instructions = models.TextField()

    def __str__(self):
        return f"Medication: {self.name}, Dosage: {self.dosage}, Frequency: {self.frequency}"

class LabTest(models.Model):
    name = models.CharField(max_length=255)
    description = models.TextField()

    def __str__(self):
        return f"Lab Test: {self.name}"

class Prescription(models.Model):
    patient = models.ForeignKey(HealthRecord, on_delete=models.CASCADE)
    medication = models.ForeignKey(Medication, on_delete=models.CASCADE)
    date_prescribed = models.DateField()
    dosage_instructions = models.TextField()
    lab_tests = models.ManyToManyField(LabTest, blank=True)

    def __str__(self):
        return f"Prescription for {self.patient.patient_name} - Medication: {self.medication.name}, Date Prescribed: {self.date_prescribed}"
