
from django.shortcuts import render, get_object_or_404
from django.http import JsonResponse
from .models import HealthRecord
from .forms import HealthRecordForm  # Import a form for creating records

# Create (Insert) operation
def create_record(request):
    if request.method == 'POST':
        form = HealthRecordForm(request.POST)
        if form.is_valid():
            form.save()
            return JsonResponse({'message': 'Record created successfully'})
    else:
        form = HealthRecordForm()
    return render(request,'index.html', {'form': form})

# Read (Retrieve) operations
def get_all_records(request):
    records = HealthRecord.objects.all()
    return render(request, 'index.html', {'records': records})

# Update operation
def update_record(request, record_id):
    record = get_object_or_404(HealthRecord, id=record_id)
    if request.method == 'POST':
        form = HealthRecordForm(request.POST, instance=record)
        if form.is_valid():
            form.save()
            return JsonResponse({'message': 'Record updated successfully'})
    else:
        form = HealthRecordForm(instance=record)
    return render(request, 'index.html', {'form': form})

# Delete operation
def delete_record(request, record_id):
    record = get_object_or_404(HealthRecord, id=record_id)
    record.delete()
    return JsonResponse({'message': 'Record deleted successfully'})
