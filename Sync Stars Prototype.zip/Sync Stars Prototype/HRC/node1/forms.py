# forms.py

from django import forms
from .models import HealthRecord

class HealthRecordForm(forms.ModelForm):
    class Meta:
        model = HealthRecord
        fields = ['node_id', 'patient_id', 'patient_name', 'diagnosis', 'treatment']
