# node1/routers.py
class Node2DatabaseRouter:
    def db_for_read(self, model, **hints):
        return settings.NODE2_DATABASE_ALIAS

    def db_for_write(self, model, **hints):
        return settings.NODE2_DATABASE_ALIAS

    def allow_relation(self, obj1, obj2, **hints):
        db1 = self.db_for_read(obj1.__class__, **hints)
        db2 = self.db_for_read(obj2.__class__, **hints)
        return db1 == db2

    def allow_migrate(self, db, app_label, model_name=None, **hints):
        if db == settings.NODE2_DATABASE_ALIAS:
            return app_label == 'node2'
        return None
