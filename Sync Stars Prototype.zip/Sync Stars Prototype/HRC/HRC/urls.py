# HRC/urls.py

from django.contrib import admin
from django.urls import path
from node1 import views as node1_views
from node2 import views as node2_views
from node3 import views as node3_views
from django.views.generic import RedirectView

#urlpatterns = [
   # path('admin/', admin.site.urls),
 #   path('node1/', node1_views.create_record, name='node1_create'),  # Use create_record view function for node1
  #  path('node2/', node2_views.create_record, name='node2_create'),  # Use create_record view function for node2
   # path('node3/', node3_views.create_record, name='node3_create'),  # Use create_record view function for node3
#]
# In HRC/urls.py

urlpatterns = [
    # Define URL patterns for nodes
    path('admin/', admin.site.urls),
    path('node1/', node1_views.create_record, name='node1_create'),
    path('node2/', node2_views.create_record, name='node2_create'),
    path('node3/', node3_views.create_record, name='node3_create'),
    path('node1/', node1_views.update_record, name='update_record'),
    path('node2/', node2_views.update_record, name='update_record'),
    path('node3/', node3_views.update_record, name='update_record'),
    path('node1/', node1_views.delete_record, name='delete_record'),
    path('node2/', node2_views.delete_record, name='delete_record'),
    path('node3/', node3_views.delete_record, name='delete_record'),


    # Define a default URL pattern for the root path
    path('', RedirectView.as_view(url='node1')),  # Redirect to node1
]
